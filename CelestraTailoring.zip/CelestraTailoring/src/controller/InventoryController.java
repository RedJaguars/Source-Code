/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import db.DatabaseConnection;
import model.InventoryModel;

/**
 *
 * @author Camille
 */
public class InventoryController extends Controller {
    public InventoryController() {
        
    }
    
    public void addInventory(String inventoryName, double quantityInStock, 
            String description, String unit) throws Exception {
        InventoryModel inventoryModel = new InventoryModel();
        inventoryModel.getItem(InventoryModel.INVENTORY_NAME).setValue(inventoryName);
        inventoryModel.getItem(InventoryModel.QUANTITY_IN_STOCK).setValue(quantityInStock);
        inventoryModel.getItem(InventoryModel.DESCRIPTION).setValue(description);
        inventoryModel.getItem(InventoryModel.UNIT).setValue(unit);
        inventoryModel.insert(DatabaseConnection.getInstance().getConnection());
    }
}
