/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Camille
 */
public class OrderListPanel implements ActionListener {
    private JButton btnAddNewOrder;
    
    private JTable tableOrders;
    
    private MainFrame mainFrame;
    
    private JPanel orderListPanel;
    
    public OrderListPanel(MainFrame frame) {
        mainFrame = frame;
        
        orderListPanel = new JPanel();
        
        JLabel lblListOfOrders = new JLabel("List of Orders");
        lblListOfOrders.setBounds(15, 20, 119, 25);
        lblListOfOrders.setFont(new Font("Tahoma", Font.PLAIN, 15));
        
        tableOrders = new JTable();
        tableOrders.setBounds(15, 50, 555, 240);
        
        btnAddNewOrder = new JButton("Add Order");
        btnAddNewOrder.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnAddNewOrder.setBounds(450, 20, 119, 20);
        
        btnAddNewOrder.addActionListener(this);
        
        orderListPanel.add(btnAddNewOrder);
        orderListPanel.add(tableOrders);
        orderListPanel.add(lblListOfOrders);
        
        orderListPanel.setBounds(200, 0, 600, 300);
        orderListPanel.setVisible(true);
        orderListPanel.setLayout(null);
    }
    
    public void actionPerformed(ActionEvent arg0) {
        if(arg0.getSource() == this.btnAddNewOrder){
            mainFrame.removeSecondPanelContent();
            mainFrame.setSecondPanelContent(new AddOrderPanel(mainFrame).getPanel(), new JPanel());
        }
    }
    
    public JPanel getPanel() {
        return orderListPanel;
    }
}
